
import random
from database.db import update_balance
from utils.fairness import get_combined_seed, store_seed, get_seed

async def spin_roulette(user_id: int, bet_number: int, amount: int):
    # Сохраняем сид и хеш
    client_seed = str(random.randint(100000, 999999))
    data = await get_seed(user_id)
    if not data:
        await store_seed(user_id)
        data = await get_seed(user_id)
    server_seed, _ = data
    spin_value = get_combined_seed(server_seed, client_seed) % 37
    win = spin_value == bet_number
    if win:
        await update_balance(user_id, amount * 36)
    return spin_value, win
