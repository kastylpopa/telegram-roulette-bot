
import hashlib, os
from database.db import save_seed, get_seed, delete_seed

def generate_server_seed():
    return os.urandom(16).hex()

def hash_seed(seed: str):
    return hashlib.sha256(seed.encode()).hexdigest()

def get_combined_seed(server_seed: str, client_seed: str):
    combined = server_seed + client_seed
    return int(hashlib.sha256(combined.encode()).hexdigest(), 16)

async def store_seed(user_id: int):
    seed = generate_server_seed()
    hashed = hash_seed(seed)
    await save_seed(user_id, seed, hashed)
    return hashed

async def reveal_seed(user_id: int):
    data = await get_seed(user_id)
    if data:
        server_seed, hash_ = data
        await delete_seed(user_id)
        return {'server_seed': server_seed, 'hash': hash_}
    return None
