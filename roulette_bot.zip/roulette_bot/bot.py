
from aiogram import Bot, Dispatcher, types
from aiogram.types import Message
from aiogram.utils import executor
from config import BOT_TOKEN
from database.db import init_db, add_user, get_user_balance, place_bet, get_last_result
from utils.roulette_logic import spin_roulette
from utils.fairness import generate_server_seed, get_combined_seed, hash_seed, store_seed, reveal_seed

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def start_command(message: Message):
    user_id = message.from_user.id
    await add_user(user_id)
    await message.answer("🎰 Добро пожаловать в Рулетку! Ваш баланс: 1000 монет.
Введите команду /bet число сумма")

@dp.message_handler(commands=['balance'])
async def balance_command(message: Message):
    user_id = message.from_user.id
    balance = await get_user_balance(user_id)
    await message.answer(f"💰 Ваш текущий баланс: {balance} монет.")

@dp.message_handler(commands=['bet'])
async def bet_command(message: Message):
    user_id = message.from_user.id
    try:
        _, number, amount = message.text.split()
        number, amount = int(number), int(amount)
        if not 0 <= number <= 36:
            raise ValueError
        bet_ok = await place_bet(user_id, number, amount)
        if not bet_ok:
            await message.answer("❌ Недостаточно средств.")
            return
        result, win = await spin_roulette(user_id, number, amount)
        await message.answer(f"🎯 Выпало число: {result}.
{'✅ Вы выиграли!' if win else '❌ Вы проиграли.'}")
    except Exception:
        await message.answer("❗ Пример: /bet 17 100")

@dp.message_handler(commands=['fair'])
async def fair_command(message: Message):
    user_id = message.from_user.id
    reveal = await reveal_seed(user_id)
    if reveal:
        await message.answer(f"🔒 Хеш: {reveal['hash']}
🔑 Seed: {reveal['server_seed']}")
    else:
        await message.answer("❌ Нет активной игры.")

if __name__ == '__main__':
    import asyncio
    asyncio.run(init_db())
    executor.start_polling(dp, skip_updates=True)
