
import aiosqlite

async def init_db():
    async with aiosqlite.connect("roulette.db") as db:
        await db.execute("""CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            balance INTEGER DEFAULT 1000
        )""")
        await db.execute("""CREATE TABLE IF NOT EXISTS seeds (
            user_id INTEGER PRIMARY KEY,
            server_seed TEXT,
            hash TEXT
        )""")
        await db.commit()

async def add_user(user_id: int):
    async with aiosqlite.connect("roulette.db") as db:
        await db.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
        await db.commit()

async def get_user_balance(user_id: int):
    async with aiosqlite.connect("roulette.db") as db:
        cursor = await db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        return row[0] if row else 0

async def place_bet(user_id: int, number: int, amount: int):
    async with aiosqlite.connect("roulette.db") as db:
        cursor = await db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        if row and row[0] >= amount:
            await db.execute("UPDATE users SET balance = balance - ? WHERE user_id = ?", (amount, user_id))
            await db.commit()
            return True
        return False

async def update_balance(user_id: int, amount: int):
    async with aiosqlite.connect("roulette.db") as db:
        await db.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id))
        await db.commit()

async def save_seed(user_id: int, server_seed: str, hash_: str):
    async with aiosqlite.connect("roulette.db") as db:
        await db.execute("REPLACE INTO seeds (user_id, server_seed, hash) VALUES (?, ?, ?)", (user_id, server_seed, hash_))
        await db.commit()

async def get_seed(user_id: int):
    async with aiosqlite.connect("roulette.db") as db:
        cursor = await db.execute("SELECT server_seed, hash FROM seeds WHERE user_id = ?", (user_id,))
        return await cursor.fetchone()

async def delete_seed(user_id: int):
    async with aiosqlite.connect("roulette.db") as db:
        await db.execute("DELETE FROM seeds WHERE user_id = ?", (user_id,))
        await db.commit()
